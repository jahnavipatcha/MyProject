package com.cg.university.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.university.entity.Application;
import com.cg.university.entity.ProgramsOffered;
import com.cg.university.entity.ProgramsScheduled;
import com.cg.university.exception.UniversityManagementException;
import com.cg.university.service.ApplicationServ;
import com.cg.university.service.ProgramsOfferedServ;
import com.cg.university.service.ProgramsScheduledServ;

@RestController
public class UniversityController {
	@Autowired
	private ProgramsScheduledServ programsScheduledServ;
/******************Applicant*******************/
@RequestMapping(value="/ProgramsScheduled")	
public List<ProgramsScheduled> getAllPrograms(){
	return programsScheduledServ.getAllPrograms();
}

@Autowired
private ApplicationServ applicationServ;

@RequestMapping(value="/Application",method=RequestMethod.POST)
public Application apply(@RequestBody Application application) throws UniversityManagementException {
	try {
	return applicationServ.apply(application);
	}
	catch(Exception e) {
		throw new UniversityManagementException(204,e.getMessage());
	}
}

@RequestMapping(value="/getStatusApplication/{applicationId}")
public String getStatus(@PathVariable int applicationId) {
	return applicationServ.getStatus(applicationId);
}
/***************************MAC***************************************/

@RequestMapping(value="/Application/{scheduledProgramID}")
public Optional<Application> getApplications(@PathVariable int scheduledProgramID) {
	return applicationServ.getApplications(scheduledProgramID);
}


@RequestMapping(value="/Application/{applicationId}",method=RequestMethod.PUT)
public Application acceptOrReject(@RequestBody Application application,@PathVariable int applicationId) {
	return applicationServ.acceptOrReject(application,applicationId);
}



@RequestMapping(value="/confirmOrRejectApplication/{applicationId}",method=RequestMethod.PUT)
public Application confirmOrReject(@RequestBody Application application,@PathVariable int applicationId) {
	return applicationServ.confirmOrReject(application,applicationId);
}




/**********************Admin(managing ProgramsScheduled)****************************/
@RequestMapping(value="/ProgramsScheduled",method=RequestMethod.POST)
public ProgramsScheduled managePrograms(@RequestBody ProgramsScheduled programscheduled) {
	
	return programsScheduledServ.managePrograms(programscheduled);
}

@RequestMapping(value="/ProgramsScheduled",method=RequestMethod.PUT)
public ProgramsScheduled updatePrograms(@RequestBody ProgramsScheduled programscheduled) {
	return programsScheduledServ.updatePrograms(programscheduled);
}

@RequestMapping(value="/ProgramsScheduled/{scheduledProgramID}",method=RequestMethod.DELETE)
public String deletePrograms(@PathVariable int scheduledProgramID) {
	return programsScheduledServ.deletePrograms(scheduledProgramID);

}
/**********************Admin(managing Offered)***************************/

@Autowired
private ProgramsOfferedServ programsOfferedServ;


@RequestMapping(value="/ProgramsOffered",method=RequestMethod.POST)
public ProgramsOffered addPrograms(@RequestBody ProgramsOffered programsOffered) {
	return programsOfferedServ.add(programsOffered);
}

@RequestMapping(value="/ProgramsOffered",method=RequestMethod.PUT)
public ProgramsOffered update(@RequestBody ProgramsOffered programsOffered) {
	return programsOfferedServ.update(programsOffered);
}

@RequestMapping(value="/ProgramsOffered/{programName}",method=RequestMethod.DELETE)
public String deletePrograms(@PathVariable String programName) {
	return programsOfferedServ.delete(programName);

}

@RequestMapping(value="/ProgramsOffered")	
public List<ProgramsOffered> getPrograms(){
	return programsOfferedServ.getPrograms();
}
/***************************Admin(Report)*****************************/

@RequestMapping(value="/ApplicationGet/{status}",method=RequestMethod.GET)
public List<Application> getAllApplicants(@PathVariable String status) {
	return applicationServ.getApplicants(status);
}

@RequestMapping(value="/ProgramsScheduledProgram/{startDate}/{endDate}")
public ProgramsScheduled getParticularProgram(@PathVariable String startDate,@PathVariable String endDate) {
	startDate=startDate.replace('-', '/');
	endDate=endDate.replace('-', '/');
    return programsScheduledServ.getParticularProgram(startDate,endDate);
}


}
